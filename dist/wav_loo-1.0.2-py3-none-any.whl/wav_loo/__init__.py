"""
WAV Finder - A tool to find WAV files from URLs or local paths.
"""

from .finder import WavFinder

__version__ = "1.0.2"
__author__ = "Your Name"
__email__ = "your.email@example.com"

__all__ = ["WavFinder"] 